# How to run
 

Step 1 : Install idle 3.8.6 web installed 64 bit for all users while installing. 
Step 2 : Install xampp add python on apache config files.
Step 3 : Install pymysql using pip in cmd. 
Step 4 : Replace the path of idle in 1st line with your local system path on all .py files. 
Step 5 : Replace the path of pymysql in 3rd line with your local system installed path in all.py files. 
Step 6 : Open xampp start apache, mysql. 
Step 7 : Place all files on c>xampp>htdocs>folder. 
Step 8 : In browser type localhost/folder.
